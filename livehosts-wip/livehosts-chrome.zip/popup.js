angular.module('liveHosts', [
  'hostData'
]);